-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 27, 2022 at 09:12 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `assignment`
--

-- --------------------------------------------------------

--
-- Table structure for table `bar`
--

CREATE TABLE `bar` (
  `bar_Id` int(11) NOT NULL,
  `Bar_Type` varchar(200) NOT NULL,
  `Bar_Price` int(11) NOT NULL,
  `Booking_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bar`
--

INSERT INTO `bar` (`bar_Id`, `Bar_Type`, `Bar_Price`, `Booking_ID`) VALUES
(2, 'Hard Drink', 2000, 20),
(3, 'Cold Drink', 300, 20);

-- --------------------------------------------------------

--
-- Table structure for table `billing`
--

CREATE TABLE `billing` (
  `Billing_ID` int(11) NOT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Drink_Price` int(11) DEFAULT NULL,
  `Service_price` int(11) DEFAULT NULL,
  `Food_Price` int(11) DEFAULT NULL,
  `Room_Price` int(11) DEFAULT NULL,
  `Total_Bill` double(10,1) DEFAULT NULL,
  `Return_Amount` double(10,1) DEFAULT NULL,
  `Discount` double(10,1) DEFAULT NULL,
  `Billing_Status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `billing`
--

INSERT INTO `billing` (`Billing_ID`, `Name`, `Drink_Price`, `Service_price`, `Food_Price`, `Room_Price`, `Total_Bill`, `Return_Amount`, `Discount`, `Billing_Status`) VALUES
(1, 'aaa', 2000, 2421, 400, 24000, 0.0, 7.0, 2690.0, 'Paid'),
(2, 'aaa', 300, 2268, 400, 24000, 0.0, 1809.0, 2520.0, 'Paid'),
(3, 'aaa', 2000, 2421, 400, 24000, 0.0, 9907.0, 2690.0, 'Paid'),
(4, 'aaa', 300, 2268, 400, 24000, 0.0, 1809.0, 2520.0, 'Paid'),
(5, 'aaa', 300, 2268, 400, 24000, 0.0, 1809.0, 2520.0, 'Paid'),
(6, 'aaa', 300, 2142, 400, 24000, 0.0, 3375.0, 3780.0, 'Paid'),
(7, 'aaa', 300, 2250, 200, 24000, 0.0, 2033.0, 2500.0, 'Paid');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `Booking_ID` int(10) NOT NULL,
  `Start_Date` date NOT NULL,
  `End_Date` date NOT NULL,
  `Prefered_Room` varchar(20) NOT NULL,
  `Room_Price` decimal(11,3) NOT NULL,
  `Booking_Status` varchar(20) DEFAULT NULL,
  `Customer_ID` int(10) DEFAULT NULL,
  `room_Id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`Booking_ID`, `Start_Date`, `End_Date`, `Prefered_Room`, `Room_Price`, `Booking_Status`, `Customer_ID`, `room_Id`) VALUES
(20, '2022-05-26', '2022-05-14', 'Double', '2000.000', 'CheckedIn', 1, 200),
(31, '2022-05-28', '2022-05-28', 'Single', '1000.000', 'CheckedIn', 11, 201),
(32, '2022-05-28', '2022-05-30', 'Twin', '3000.000', 'CheckedIn', 11, 302),
(40, '2022-05-27', '2022-05-29', 'Twin', '3000.000', 'Booked', 11, 303);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_ID` int(10) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Contact_No` int(20) NOT NULL,
  `Credit_Card_Information` varchar(20) NOT NULL,
  `Customer_Type` varchar(20) NOT NULL,
  `Password` varchar(10) NOT NULL,
  `Company_Name` varchar(20) DEFAULT NULL,
  `Date_Of_Birth` varchar(50) NOT NULL,
  `Company_Registration_No` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Customer_ID`, `Name`, `Email`, `Gender`, `Contact_No`, `Credit_Card_Information`, `Customer_Type`, `Password`, `Company_Name`, `Date_Of_Birth`, `Company_Registration_No`) VALUES
(1, 'aaa', 'abc', 'male', 123456, '2345678', 'Customer', 'abc', '', 'Mon May 02 22:54:08 NPT 2022', ''),
(11, 'Deepesh', 'Dipesh@gmail.com', 'male', 984009001, '2112-1122-6754', 'Customer', 'dipesh', '', 'Thu May 29 00:00:00 NPT 2003', ''),
(19, 'Raunak', 'raunak@gmail.com', 'female', 984123654, '9862-1222-7423', 'Bar and RestroStaff', 'raunak', '', 'Thu May 30 00:00:00 NPT 2002', ''),
(20, 'Aryan', 'aryan@gmail.com', 'male', 982112390, '1002-9586-2341', 'corporatecustomer', 'aryanstha', 'Mellanium Soft', 'Mon May 06 00:00:00 NPT 2002', '13123'),
(21, 'Aditi Shrestha', 'aditi1@gmail.com', 'female', 98077654, '1223-4321-9876', 'Receptionist', 'Aditi', '', 'Thu May 20 01:27:46 NPT 2004', ''),
(22, 'Ram das', 'Ram@gmail.com', 'male', 986754545, '1234-1232-2332-3212', 'corporatecustomer', 'ram123', 'millionsoft', 'Sun May 01 04:13:23 NPT 2005', '1234'),
(23, 'Hannah', 'hannah@gmail.com', 'male', 98776543, '8884-7765-1123', 'Receptionist', 'lana123AS', '', 'Wed May 26 00:00:00 NPT 2004', ''),
(24, 'Alison', 'alison@gmail.com', 'female', 98667753, '2223-1237-8889-2342', 'Receptionist', 'alii12', '', 'Tue May 18 00:00:00 NPT 2004', '');

-- --------------------------------------------------------

--
-- Table structure for table `restro`
--

CREATE TABLE `restro` (
  `Restro_Id` int(11) NOT NULL,
  `Food_Type` varchar(200) NOT NULL,
  `Food_Price` int(11) NOT NULL,
  `Booking_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `restro`
--

INSERT INTO `restro` (`Restro_Id`, `Food_Type`, `Food_Price`, `Booking_ID`) VALUES
(7, 'Lunch', 500, 20),
(8, 'Lunch', 500, 20),
(9, 'Lunch', 500, 20),
(10, 'Dinner', 600, 20);

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `room_Id` int(11) NOT NULL,
  `room_Type` varchar(50) NOT NULL,
  `room_Price` decimal(11,2) NOT NULL,
  `room_Status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`room_Id`, `room_Type`, `room_Price`, `room_Status`) VALUES
(0, '', '0.00', ''),
(100, 'Single', '1000.00', 'Available'),
(101, 'Single', '1000.00', 'Available'),
(102, 'Single', '1000.00', 'Available'),
(103, 'Single', '1000.00', 'Available'),
(104, 'Single', '1000.00', 'Available'),
(105, 'Single', '1000.00', 'Available'),
(106, 'Single', '1000.00', 'Available'),
(107, 'Single', '1000.00', 'Available'),
(200, 'Double', '2000.00', 'Booked'),
(201, 'Double', '2000.00', 'Booked'),
(202, 'Double', '2000.00', 'Booked'),
(203, 'Double', '2000.00', 'Available'),
(204, 'Double', '2000.00', 'Booked'),
(205, 'Double', '2000.00', 'Booked'),
(206, 'Double', '2000.00', 'Available'),
(300, 'Twin', '3000.00', 'Booked'),
(301, 'Twin', '3000.00', 'Booked'),
(302, 'Twin', '3000.00', 'Booked'),
(303, 'Twin', '3000.00', 'Booked'),
(304, 'Twin', '3000.00', 'Available'),
(305, 'Twin', '3000.00', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `service_Id` int(11) NOT NULL,
  `service_Type` varchar(200) NOT NULL,
  `service_price` int(11) NOT NULL,
  `Booking_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`service_Id`, `service_Type`, `service_price`, `Booking_ID`) VALUES
(6, 'Gym', 400, 20),
(7, 'Laundry', 200, 20),
(8, 'Gym', 400, 20);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bar`
--
ALTER TABLE `bar`
  ADD PRIMARY KEY (`bar_Id`),
  ADD KEY `Booking_ID` (`Booking_ID`);

--
-- Indexes for table `billing`
--
ALTER TABLE `billing`
  ADD PRIMARY KEY (`Billing_ID`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`Booking_ID`),
  ADD KEY `Customer_ID` (`Customer_ID`),
  ADD KEY `room_Id` (`room_Id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_ID`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD UNIQUE KEY `Contact_No` (`Contact_No`),
  ADD UNIQUE KEY `Contact_No_2` (`Contact_No`);

--
-- Indexes for table `restro`
--
ALTER TABLE `restro`
  ADD PRIMARY KEY (`Restro_Id`),
  ADD KEY `Booking_ID` (`Booking_ID`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`room_Id`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`service_Id`),
  ADD KEY `Booking_ID` (`Booking_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bar`
--
ALTER TABLE `bar`
  MODIFY `bar_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `billing`
--
ALTER TABLE `billing`
  MODIFY `Billing_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `Booking_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `Customer_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `restro`
--
ALTER TABLE `restro`
  MODIFY `Restro_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
  MODIFY `service_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bar`
--
ALTER TABLE `bar`
  ADD CONSTRAINT `bar_ibfk_1` FOREIGN KEY (`Booking_ID`) REFERENCES `booking` (`Booking_ID`);

--
-- Constraints for table `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `booking_ibfk_1` FOREIGN KEY (`Customer_ID`) REFERENCES `customer` (`Customer_ID`),
  ADD CONSTRAINT `booking_ibfk_2` FOREIGN KEY (`room_Id`) REFERENCES `room` (`room_Id`);

--
-- Constraints for table `restro`
--
ALTER TABLE `restro`
  ADD CONSTRAINT `restro_ibfk_1` FOREIGN KEY (`Booking_ID`) REFERENCES `booking` (`Booking_ID`);

--
-- Constraints for table `service`
--
ALTER TABLE `service`
  ADD CONSTRAINT `service_ibfk_1` FOREIGN KEY (`Booking_ID`) REFERENCES `booking` (`Booking_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
