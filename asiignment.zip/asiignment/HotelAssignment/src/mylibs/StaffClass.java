 package mylibs;

public class StaffClass {

}
