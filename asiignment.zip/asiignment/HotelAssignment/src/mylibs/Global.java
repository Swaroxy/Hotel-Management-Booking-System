package mylibs;

public class Global { 
	public final static String ROLES[] = {"Manager", "Staff", "Customer", "corporatecustomer"} ;
	public final static String[] ROOM_TYPE= {"Single","Double","Twin"};
	public final static double[] ROOM_PRICE = {7000,10000,12000};
	public final static String[] ROOM_NUMBER = {"100","101","102","200","201","202"};
}



